<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Contacto;

class ContactoController extends Controller
{
    public function listado(){
        $contactos = Contacto::all();
        $vac = compact("contactos");
        return view('/listadoContactos',$vac);
    }

    public function agregar(Request $req){
    	$contactoNuevo = new Contacto();
    	$contactoNuevo->email=$req["email"];
    	$contactoNuevo->comentario=$req["comentario"];
    	$contactoNuevo->save();
        return redirect("/home");
    }
}
