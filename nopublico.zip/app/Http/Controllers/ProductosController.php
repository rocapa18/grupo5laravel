<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Producto;
class ProductosController extends Controller
{
    public function listado(){
    	$productos = Producto::all();
    	$vac=compact("productos");
        return view("productos",$vac);
    }

    public function detalle(){
    	$productos = Producto::where("id", "=", 1)->get();
    	$vac = compact("productos");
        return view("detalle",$vac);
    }
}
