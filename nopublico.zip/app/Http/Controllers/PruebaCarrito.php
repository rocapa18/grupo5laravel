<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PruebaCarrito extends Controller
{
    public function ver(){
        return view('prueba');
    }
}
