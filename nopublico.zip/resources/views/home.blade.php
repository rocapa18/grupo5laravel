@extends("plantilla")
@section("principal")
<div class="animation">
    <div id="particles-js"></div>
</div>

<div class="mainlogo">
    <h1>Recursos Para Desarrollo WEB</h1>
    <h3>Los Mejores Cursos a tu Alcance</h3>
    <figure><img src="img/logo5t.png" alt="logo"></figure>

    <div class="enlace">
        <a href="productos" target="blank">Cursos Disponibles</a>
    </div>

</div>
@endsection