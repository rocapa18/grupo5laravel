@extends("plantilla")
@section("principal")
     <head>
          <link rel="stylesheet" href="css/styleFaq.css">
     </head>
     <section>
          <div class="animation">
               <div id="particles-js">
               </div>
          </div>
          <div class="faq">

               <h1 class="titulo">Perfil de Usuario</h1>
               <hr class="lineahorizontal">
                    @foreach($perfiles as $perfil)
                         <img class="imagenperfil" src="img/1.png">
                         <div class="PERFIL">
                              <p>{{$perfil->name}}</p>
                              <p>{{$perfil->email}}</p>
                         </div>    
                    @endforeach                    
          </div>
     </section>
@endsection
