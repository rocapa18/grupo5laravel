@extends("plantilla")
@section("principal")

<head>
<link rel="stylesheet" href="css/styleProductos.css">
</head>
<div>
  <a class="add" href="/productoNuevo">Agregar Nuevo Curso</a>  
</div>

<section>
  <!-- -->
  @forelse($productos as $producto)
    <article class="product">
          <div class="photo-container">
            @if ($producto->id <= 6)
              <img src='{{$producto->imagen}}'>
            @endif
            @if ($producto->id > 6)
              <img src='img/x.jpg'>
            @endif
          </div>
          <div class="titulo">
            <h2>{{$producto->nombre}}</h2>
          </div>
          <div class="descripcion">
            <p>{{$producto->descripcion}}</p>
          </div>
          <a class="more" href="/detalle">Detalle</a>
          <a class="edit" href="/detalleEditar">Modificar</a>
          <a class="remove" href="/detalleEliminar">Eliminar</a>
    </article>
  @empty
  @endforelse
</section>



@endsection