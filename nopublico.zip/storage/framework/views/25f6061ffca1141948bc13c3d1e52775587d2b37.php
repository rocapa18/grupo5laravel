<?php $__env->startSection("principal"); ?>
     <head>
          <link rel="stylesheet" href="css/styleFaq.css">
     </head>
     <section>
               <div class="faq">
               
               <h1 class="titulo">Comentarios</h1>
               <a class="add" href="/contacto">[Agregar Nuevo Listado de Contacto]</a>

               <hr class="lineahorizontal">
                    <ol>                         
                    <?php $__currentLoopData = $contactos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <div class="FAQ"><li id="faq">
                         <?php echo e($contacto->email); ?></li>  
                         <p>
                         <?php echo e($contacto->comentario); ?>

                         </p>
                         <p>
                              <a class="edit" href="/contactoEditar">[Editar]</a>
                              <a class="remove" href="/contactoEliminar">[Eliminar]</a>
                         </p>
                         </div>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
                    </ol>
               </div>
     </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\grupo5laravel\resources\views//listadoContactos.blade.php ENDPATH**/ ?>