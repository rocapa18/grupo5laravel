<?php $__env->startSection("principal"); ?>

<head>
<link rel="stylesheet" href="css/styleProductos.css">
</head>
<div>
  <a class="add" href="/productoNuevo">Agregar Nuevo Curso</a>  
</div>

<section>
  <!-- -->
  <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <article class="product">
          <div class="photo-container">
            <?php if($producto->id <= 6): ?>
              <img src='<?php echo e($producto->imagen); ?>'>
            <?php endif; ?>
            <?php if($producto->id > 6): ?>
              <img src='img/x.jpg'>
            <?php endif; ?>
          </div>
          <div class="titulo">
            <h2><?php echo e($producto->nombre); ?></h2>
          </div>
          <div class="descripcion">
            <p><?php echo e($producto->descripcion); ?></p>
          </div>
          <a class="more" href="/detalle">Detalle</a>
          <a class="edit" href="/detalleEditar">Modificar</a>
          <a class="remove" href="/detalleEliminar">Eliminar</a>
    </article>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <?php endif; ?>
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make("plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\grupo5laravel\resources\views/productos.blade.php ENDPATH**/ ?>