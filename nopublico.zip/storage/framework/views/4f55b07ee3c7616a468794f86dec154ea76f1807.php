<?php $__env->startSection("principal"); ?>
<div class="animation">
    <div id="particles-js"></div>
</div>

<div class="mainlogo">
    <h1>Recursos Para Desarrollo WEB</h1>
    <h3>Los Mejores Cursos a tu Alcance</h3>
    <figure><img src="img/logo5t.png" alt="logo"></figure>

    <div class="enlace">
        <a href="productos" target="blank">Cursos Disponibles</a>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\grupo5laravel\resources\views/home.blade.php ENDPATH**/ ?>