<?php $__env->startSection("principal"); ?>
     <head>
          <link rel="stylesheet" href="css/stylePerfil.css">
     </head>
     <section>
          <div class="animation">
               <div id="particles-js">
               </div>
          </div>
          <div class="faq">

               <h1 class="titulo">Preguntas Frecuentes</h1>
               <hr class="lineahorizontal">
                    <ol>                         
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <div class="FAQ"><li id="faq">
                         <?php echo e($faq->pregunta); ?></li>
                         <p>
                         <?php echo e($faq->respuesta); ?>

                         </p>
                         </div>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
                    </ol>
          </div>
     </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\grupo5laravel\resources\views//perfil.blade.php ENDPATH**/ ?>