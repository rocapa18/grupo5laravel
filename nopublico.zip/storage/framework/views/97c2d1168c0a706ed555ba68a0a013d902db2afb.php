<?php $__env->startSection("principal"); ?>

<head>
    <link rel="stylesheet" href="css/styleContacto.css">
</head>
<!--
<div class="animation">
    <div id="particles-js">
    </div>
</div>
   -->       
<div class="contacto">
    <h1 class="titulo">Contacto</h1>
    <a style="text-align: center;" href="/contactoListado">[Ver Listado de Contactos]</a>
    <hr class="lineahorizontal">

    <form action="/contacto" method="post">
        <?php echo e(csrf_field()); ?>

        <div class=email>
            <label for="email">Email</label>
            <div >
            <input type="email" id="email" name="email">
            </div>
        </div>

        <div class=comentario>
            <label for="comentario">Comentarios</label>
            <div id="textarea">
            <textarea name="comentario" id="comentario" cols="90" rows="5">                    
            </textarea>
            </div>
        </div> 
        <div>
            <button class="btn btn-warning mb-2 boton-submit">Enviar Comentario</button>
        </div>      
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\grupo5laravel\resources\views/contacto.blade.php ENDPATH**/ ?>