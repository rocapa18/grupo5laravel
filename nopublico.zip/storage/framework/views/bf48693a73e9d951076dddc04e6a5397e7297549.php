<?php $__env->startSection("principal"); ?>

     <head>
          <link rel="stylesheet" href="css/styleFaq.css">
     </head>
     <section>
          <div class="animation">
               <div id="particles-js">
               </div>
          </div>
          <div class="faq">
               <h1 class="titulo">Preguntas Frecuentes</h1>
               <hr class="lineahorizontal">
               <?php $__empty_1 = true; $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="FAQ"><li id="faq">
                    <?php echo e($faqs->pregunta); ?></li>
                    <p>
                    <?php echo e($faqs->respuesta); ?>

                    </p>
                    </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

               <?php endif; ?>
               </form>
          </div>
     </section>
<?php $__env->stopSection(); ?>




<?php echo $__env->make("plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\grupo5laravel\resources\views/listadoFaqs.blade.php ENDPATH**/ ?>