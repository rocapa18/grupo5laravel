<?php $__env->startSection("principal"); ?>
     <head>
          <link rel="stylesheet" href="css/styleFaq.css">
     </head>
     <section>
          <div class="animation">
               <div id="particles-js">
               </div>
          </div>
          <div class="faq">

               <h1 class="titulo">Perfil de Usuario</h1>
               <hr class="lineahorizontal">
                    <?php $__currentLoopData = $perfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <img class="imagenperfil" src="img/1.png">
                         <div class="PERFIL">
                              <p><?php echo e($perfil->name); ?></p>
                              <p><?php echo e($perfil->email); ?></p>
                         </div>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
          </div>
     </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\grupo5laravel\resources\views//listadoPerfiles.blade.php ENDPATH**/ ?>