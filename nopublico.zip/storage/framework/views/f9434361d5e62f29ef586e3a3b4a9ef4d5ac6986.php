<?php $__env->startSection("principal"); ?>

     <head>
          <link rel="stylesheet" href="css/styleFaq.css">

     </head>
     
     




     <section>
          <div class="animation">
               <div id="particles-js">
               </div>
          </div>
          <div class="faq">
               <h1 class="titulo">Preguntas Frecuentes</h1>
               <hr class="lineahorizontal">
               <form action="#" method="POST">
                    <div class="FAQ">
                         <li id="faq">Lorem ipsum dolor sit amet consectetur adipiscing elit?</li>
                         <p>Lorem ipsum dolor sit amet consectetur adipiscing elit faucibus, ullamcorper integer gravida velit aliquam diam dictumst vivamus, eu nulla ornare habitasse nunc leo dui.</p>
                    </div>
                    <div class="FAQ">
                         <li id="faq">Lorem ipsum dolor sit amet consectetur adipiscing elit?</li>
                         <p>Lorem ipsum dolor sit amet consectetur adipiscing elit faucibus, ullamcorper integer gravida velit aliquam diam dictumst vivamus, eu nulla ornare habitasse nunc leo dui.</p>
                    </div>
                    <div class="FAQ">
                         <li id="faq">Lorem ipsum dolor sit amet consectetur adipiscing elit?</li>
                         <p>Lorem ipsum dolor sit amet consectetur adipiscing elit faucibus, ullamcorper integer gravida velit aliquam diam dictumst vivamus, eu nulla ornare habitasse nunc leo dui.</p>
                     </div>
                     <div class="FAQ">
                         <li id="faq">Lorem ipsum dolor sit amet consectetur adipiscing elit?</li>
                         <p>Lorem ipsum dolor sit amet consectetur adipiscing elit faucibus, ullamcorper integer gravida velit aliquam diam dictumst vivamus, eu nulla ornare habitasse nunc leo dui.</p>
                     </div>
                    
                    
               </form>
          </div>

     </section>
<?php $__env->stopSection(); ?>




<?php echo $__env->make("plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\grupo5laravel\resources\views/faq.blade.php ENDPATH**/ ?>